<?php

/**
 * Contains configuration details for facileManager
 *
 * @package facileManager
 *
 */

/** Database credentials */
$__FM_CONFIG['db']['host'] = 'localhost';
$__FM_CONFIG['db']['user'] = 'root';
$__FM_CONFIG['db']['pass'] = '';
$__FM_CONFIG['db']['name'] = 'facileManager';

require_once(ABSPATH . 'fm-modules/facileManager/functions.php');

?>